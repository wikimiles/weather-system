# encoding=utf-8

import requests

import json

import ast 
import re 


import time

def request(year, month):
	url = "http://d1.weather.com.cn/calendar_new/" + year + "/101280701_" + year + month + ".html?_=1495685758174"
	url = "http://d1.weather.com.cn/weather_index/101010100.html"
	url = "http://d1.weather.com.cn/weather_index/101200101.html"

	headers = {

	"User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",

	"Referer": "http://www.weather.com.cn/",

	}

	return requests.get(url, headers=headers)

def parse(res):

	json_str = res.content.decode(encoding='utf-8')[11:]

	return json.loads(json_str)


if __name__ == '__main__':

	year = "2016"

	month = 1


	for i in range(month, 13):

		month = str(i) if i > 9 else "0" + str(i) #小于10的月份要补0

		res = request(year, month).content.decode(encoding='utf-8')
		res = re.sub(r'\\', '', res)
		assert "var cityDZ =" in res and "var alarmDZ =" in res and "var dataSK =" in res and "var dataZS =" in res and "var fc =" in res
		res = res.split('var cityDZ =')[1]
		res = res.split('var alarmDZ =')
		d1 = res[0].strip(';')

		res = res[1].split('var dataSK =')
		d2 = res[0].strip(';')
		res = res[1]

		res = res.split('var dataZS =')
		d3 = res[0].strip(';')
		res = res[1]

		res = res.split('var fc =')
		d4 = res[0].strip(';')
		d5 = res[1].strip(';')

		d1 = ast.literal_eval(d1)
		d2 = ast.literal_eval(d2)
		d3 = ast.literal_eval(d3)
		d4 = ast.literal_eval(d4)
		d5 = ast.literal_eval(d5)



		print('d1', d1)
		print('d2', d2)
		print('d3', d3)
		print('d4', d4)
		print('d5', d5)

