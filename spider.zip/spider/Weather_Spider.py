#coding:utf-8
import requests
import json
from lxml import etree
import jieba
import re 
import ast 

class Weather_Get():

    def __init__(self):
        self.base_ip_url='http://ip-api.com/json'
        self.location_url='https://ip.tool.chinaz.com/'
        #获取中国国内城市--number接口
        self.city_number_url='http://static.2ktq.com/sktq/common/city_China.json'
        #天气查询接口
        self.base_weather_url = "http://d1.weather.com.cn/weather_index/{}.html"
        self.headers={
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
        }
        self.item=self.get_city_item()


    def request(self,url,headers):
        """
        请求url，可自定义请求头
        :param url: 请求的url
        :param headers: 自定义的请求头
        :return: 网页文本数据
        """
        s=requests.session()
        s.keep_alive=False
        try:
            r=s.get(url,headers=headers)
            r.encoding='utf-8'
            if r.status_code==200:
                r.encoding = r.apparent_encoding
                return r.text
            else:
                return None
        except requests.exceptions.ConnectionError:
            return None

    def get_city(self):
        """
        通过ip定位到当前城市
        :return:所在省市位置信息
        """
        my_headers={
            'Connection': 'keep-alive',
            'Host': 'ip.tool.chinaz.com',
            'sec-ch-ua': '"Google Chrome";v="89", "Chromium";v="89", ";Not A Brand";v="99"',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36',
            'Upgrade-Insecure-Requests': '1'
        }
        #res = etree.HTML(self.request(self.location_url,headers=my_headers))
        res = self.request(self.location_url, headers=my_headers)
        pattern = re.compile(r'<em id="infoLocation">(.*?)</em>')
        res=pattern.findall(res)
        print(res)
        location = res[0]
        #location = res.xpath('//div[@class="WhoIpWrap jspu"]//span[@class="Whwtdhalf w30-0 lh34 tl ml80"]/em/text()')
        print('location:', location)
        #结巴分词好费时间啊
        jieba_cut_result = jieba.lcut(''.join(location))
        print('jieba_cut_result:', jieba_cut_result)
        try:
            #去除首位的国家和网络类型
            del jieba_cut_result[0]
            del jieba_cut_result[-1]
            item = {}
            # 如果结果为类似 石家庄裕华 则自动加入市区
            if jieba_cut_result[0]!=jieba_cut_result[1]:
                item['province'] = jieba_cut_result[0] + '省'
                item['city'] = jieba_cut_result[1] + "市"
                return item
            else:
                # 如果结果为类似 北京北京 则自动加入市
                item['province'] = jieba_cut_result[0] + '市'
                item['city'] = jieba_cut_result[1] + "市"
                return item
        except IndexError:
            return False

    def get_city_item(self):
        res =self.request(self.city_number_url,headers=self.headers)
        item=eval("{'cities':"+res+"}")
        return item

    def get_provinces(self):
        province=[p for p in self.item['cities']]
        #print(province)
        return province

    def get_cities(self,province):
        cities_=self.item['cities'][province]
        cities=[city for city in cities_.keys()]
        return cities

    def get_regions(self,province,city):
        regions_=self.item['cities'][province][city]
        regions=[region for region in regions_.keys()]
        #print(province,city,regions)
        return regions

    def get_city_id_by_add(self,province,city,region=''):
        if region=='':
            city_no=self.item['cities'][province][city][city].replace('CN','')

        else:
            city_no=self.item['cities'][province][city][region].replace('CN','')
        return city_no


    def get_cityid(self,province,city):
        """
        通过省、市在字典中查找对应的城市号
        :param province: 省
        :param city: 市
        :return: 城市号
        """
        if province in self.item['cities'].keys():
            try:
                #河北省唐山市唐山市（通常的省市）
                number=self.item['cities'][province].get(city).get(city).replace('CN','')
                return number
            except AttributeError:
                number=self.item['cities'][province].get(province).get(city).replace('CN','')
                return number
        else:
            print('未检索到关于{}{}的信息！'.format(province,city))

    def get_weather(self,number):
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36",
            "Referer": "http://www.weather.com.cn/",
        }
        res = requests.get(self.base_weather_url.format(number), headers=headers).content.decode(encoding='utf-8')
        #res = requests.get('http://d1.weather.com.cn/weather_index/101200101.html', headers=headers).content.decode(encoding='utf-8')
        res = re.sub(r'\\', '', res)
        assert "var cityDZ =" in res and "var alarmDZ =" in res and "var dataSK =" in res and "var dataZS =" in res and "var fc =" in res

        #print('res', res)
        res = res.split('var cityDZ =')[1]
        res = res.split('var alarmDZ =')
        d1 = res[0].strip(';')

        res = res[1].split('var dataSK =')
        d2 = res[0].strip(';')
        res = res[1]

        res = res.split('var dataZS =')
        d3 = res[0].strip(';')
        res = res[1]

        res = res.split('var fc =')
        d4 = res[0].strip(';')
        d5 = res[1].strip(';')

        d1 = ast.literal_eval(d1)
        d2 = ast.literal_eval(d2)
        d3 = ast.literal_eval(d3)
        d4 = ast.literal_eval(d4)
        d5 = ast.literal_eval(d5)

        item={}
        item['now']=d3['temp']+'℃'
        item['ganmao']=d4['zs']['gm_hint'] 

        item_list=[]
        count=0
        adict = {"01": '多云', "02": "阴", "00": "晴", "03": "", "04": "", "05": "", "06": "", "07": "小雨", "08": "中雨", "09": "大雨"}
        adict =  {
                "00": "晴",
                "01": "多云",
                "02": "阴",
                "03": "阵雨",
                "04": "雷阵雨",
                "05": "雷阵雨伴有冰雹",
                "06": "雨夹雪",
                "07": "小雨",
                "08": "中雨",
                "09": "大雨",
                "10": "暴雨",
                "11": "大暴雨",
                "12": "特大暴雨",
                "13": "阵雪",
                "14": "小雪",
                "15": "中雪",
                "16": "大雪",
                "17": "暴雪",
                "18": "雾",
                "19": "冻雨",
                "20": "沙尘暴",
                "21": "小到中雨",
                "22": "中到大雨",
                "23": "大到暴雨",
                "24": "暴雨到大暴雨",
                "25": "大暴雨到特大暴雨",
                "26": "小到中雪",
                "27": "中到大雪",
                "28": "大到暴雪",
                "29": "浮尘",
                "30": "扬沙",
                "31": "强沙尘暴",
                "53": "霾",
                "99": "无",
                "32": "浓雾",
                "49": "强浓雾",
                "54": "中度霾",
                "55": "重度霾",
                "56": "严重霾",
                "57": "大雾",
                "58": "特强浓雾",
                "301": "雨",
                "302": "雪"}
        print('hello')
        for weateher in d5['f']:
            item2={}
            if count==0:
                date=weateher['fi']+'（今天）'
            elif count==1:
                date=weateher['fi']+'（明天）'
            elif count==2:
                date=weateher['fi']+'（后天）'
            else:
                date=weateher['fi']+f'（{count}天后）'
            item2['日期']=date
            item2['天气'] = adict[weateher['fa']]

            item2['风力风向']=weateher['ff']+weateher['fh']
            item2['最低气温'] = weateher['fd']
            item2['最高气温'] = weateher['fc']
            item_list.append(item2)
            count+=1

        item['recent']=item_list
        print('hello1')
        return item

    def get_local_weather(self):
        print('get_local_weather')
        item=Weather_Get().get_city()
        print('end item', item)
        if item:
            p=item['province']
            c=item['city']
            number=Weather_Get().get_cityid(p,c)
            print('number:', number)
            weather=Weather_Get().get_weather(number)
            print('weather:', weather)
            return p+c,weather
        else:
            return False